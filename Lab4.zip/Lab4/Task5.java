class Student {
    private int id;
    private String name;
    private double[] grades;

  
    Student(int id, String name, double[] grades) {
        this.id = id;
        this.name = name;
        this.grades = grades;
    }

    void displayAverageGrade() {
        double sum = 0;
        for (double grade : grades) {
            sum += grade;
        }
        double average = sum / grades.length;
        System.out.println("Average Grade of " + name + ": " + average);
    }

        double[] calcPercentage() {
        double[] percentages = new double[grades.length];
        for (int i = 0; i < grades.length; i++) {
            percentages[i] = (grades[i] / 200) * 100;
        }
        return percentages;
    }


    String concatIdName() {
        return id + " - " + name;
    }
}

public class Task5 {
    public static void main(String[] args) {

        double[] grades1 = {180, 175, 190, 200, 185};
        double[] grades2 = {160, 170, 165, 180, 175};

        Student student1 = new Student(101, "Alice", grades1);
        Student student2 = new Student(102, "Bob", grades2);


        student1.displayAverageGrade();
        student2.displayAverageGrade();

    
        double[] percentages1 = student1.calcPercentage();
        double[] percentages2 = student2.calcPercentage();
        
        System.out.print("Percentages of Alice: ");
        for (double p : percentages1) {
            System.out.print(p + "% ");
        }
        System.out.println();
        
        System.out.print("Percentages of Bob: ");
        for (double p : percentages2) {
            System.out.print(p + "% ");
        }
        System.out.println();

        System.out.println("Concatenated ID and Name: " + student1.concatIdName());
        System.out.println("Concatenated ID and Name: " + student2.concatIdName());
    }
}

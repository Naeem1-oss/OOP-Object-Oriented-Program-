class Circle {
    double radius;
    String color;

    Circle(double radius, String color) {
        this.radius = radius;
        this.color = color;
    }

    double calculateArea() {
        return Math.PI * radius * radius;
    }
}

public class Task2 {
    public static void main(String[] args) {

        Circle redCircle = new Circle(5.0, "Red");
        Circle greenCircle = new Circle(7.0, "Green");

        System.out.println("Red Circle - Radius: " + redCircle.radius + ", Color: " + redCircle.color);
        System.out.println("Green Circle - Radius: " + greenCircle.radius + ", Color: " + greenCircle.color);
        
        System.out.println("Red Circle Area: " + redCircle.calculateArea());
        System.out.println("Green Circle Area: " + greenCircle.calculateArea());
    }
}

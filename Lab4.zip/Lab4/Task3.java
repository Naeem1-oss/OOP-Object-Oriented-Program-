class BankAccount {
    private double balance;
    private int accountNumber;

    
    BankAccount(int accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

   
    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited " + amount + " into Account " + accountNumber);
    }

    
    void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn " + amount + " from Account " + accountNumber);
        } else {
            System.out.println("Insufficient balance in Account " + accountNumber);
        }
    }

    
    void checkBalance() {
        System.out.println("Account " + accountNumber + " Balance: " + balance);
    }
}

public class Task3 {
    public static void main(String[] args) {
        
        BankAccount acc1 = new BankAccount(101, 1000);
        BankAccount acc2 = new BankAccount(102, 500);

        
        acc1.deposit(500);
        acc2.deposit(1500);

        
        acc1.checkBalance();
        acc2.checkBalance();

        
        acc1.withdraw(500);
        acc1.checkBalance();

        acc2.withdraw(3000);
    }
}

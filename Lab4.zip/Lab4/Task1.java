class Circle {
    double radius;
    String color;
    Circle() {
        this.radius = 0.0;
        this.color = "Unknown";
    }
void calculateArea() {
        double area = Math.PI * radius * radius;
        System.out.println("Circle with radius " + radius + " has an area of: " + area);
    }
}

public class Task1 {
    public static void main(String[] args) {

        Circle redCircle = new Circle();
        Circle greenCircle = new Circle();
        redCircle.radius = 5.0;
        redCircle.color = "Red";
        greenCircle.radius = 7.0;
        greenCircle.color = "Green";

        System.out.println("Red Circle - Radius: " + redCircle.radius + ", Color: " + redCircle.color);
        System.out.println("Green Circle - Radius: " + greenCircle.radius + ", Color: " + greenCircle.color);

        redCircle.calculateArea();
        greenCircle.calculateArea();
    }
}
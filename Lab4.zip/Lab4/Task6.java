class Matrix {
    private int rows;
    private int cols;
    private int[][] matx;


    Matrix(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.matx = new int[rows][cols];
    }


    void getMatrix() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matx[i][j] + " ");
            }
            System.out.println();
        }
    }


    void setElement(int row, int col, int value) {
        if (row >= 0 && row < rows && col >= 0 && col < cols) {
            matx[row][col] = value;
        } else {
            System.out.println("Invalid row or column index");
        }
    }
}

public class Task6 {
    public static void main(String[] args) {

        Matrix matrix1 = new Matrix(4, 3);
        Matrix matrix2 = new Matrix(3, 3);


        matrix1.setElement(0, 0, 1);
        matrix1.setElement(0, 1, 2);
        matrix1.setElement(0, 2, 3);
        matrix1.setElement(1, 0, 4);
        matrix1.setElement(1, 1, 5);
        matrix1.setElement(1, 2, 6);
        matrix1.setElement(2, 0, 7);
        matrix1.setElement(2, 1, 8);
        matrix1.setElement(2, 2, 9);
        matrix1.setElement(3, 0, 10);
        matrix1.setElement(3, 1, 11);
        matrix1.setElement(3, 2, 12);


        matrix2.setElement(0, 0, 1);
        matrix2.setElement(0, 1, 2);
        matrix2.setElement(0, 2, 3);
        matrix2.setElement(1, 0, 4);
        matrix2.setElement(1, 1, 5);
        matrix2.setElement(1, 2, 6);
        matrix2.setElement(2, 0, 7);
        matrix2.setElement(2, 1, 8);
        matrix2.setElement(2, 2, 9);

        
        matrix1.setElement(1, 2, 3);

        System.out.println("Matrix1:");
        matrix1.getMatrix();
        
        System.out.println("Matrix2:");
        matrix2.getMatrix();
    }
}

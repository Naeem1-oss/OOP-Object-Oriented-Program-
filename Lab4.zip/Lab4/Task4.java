class Employee {
    private String name;
    private int yearOfJoining;
    private String address;

    
    Employee(String name, int yearOfJoining, String address) {
        this.name = name;
        this.yearOfJoining = yearOfJoining;
        this.address = address;
    }

   
    void displayInfo() {
        System.out.printf("%-10s %-15d %-15s\n", name, yearOfJoining, address);
    }
}

public class Task4 {
    public static void main(String[] args) {
       
        Employee emp1 = new Employee("Robert", 1994, "WallsStreat");
        Employee emp2 = new Employee("Sam", 2000, "WallsStreat");
        Employee emp3 = new Employee("John", 1999, "WallsStreat");

        
        System.out.printf("%-10s %-15s %-15s\n", "Name", "Year of Joining", "Address");
        emp1.displayInfo();
        emp2.displayInfo();
        emp3.displayInfo();
    }
}
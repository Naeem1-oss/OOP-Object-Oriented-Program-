class Book2{
	String Title;
	String Author;
	boolean isAvailable;

	Book2(String Title, String Author ){
  this.Title=Title;
  this.Author=Author;
  this.isAvailable=true;

	}

	public void borrowBook(){
    if(isAvailable){
    	isAvailable=false;
    	System.out.println("Book has been borrowed not avialable .");
    }
 else {
 	System.out.println(" The  book is Already borrowed .");
 }
}
public void returnBook(){
	isAvailable=true;
	System.out.println("Book is avialable .");
}

  public void displayBookDetails(){
  	System.out.println("Book  name : "+Title);
  	  	System.out.println("Author  name : "+Author);  	
  	  	System.out.println("Availability :"+(isAvailable ? " Available ":" Not Available"));
  }
 public static void main(String [] args){
Book2 B = new Book2("  Chemical Bonding"," Musbah Ali Tunio");

B.displayBookDetails();

B.borrowBook();
B.displayBookDetails();

B.returnBook();
B.displayBookDetails();

B.borrowBook();
B.borrowBook();
B.displayBookDetails();
 }
	
}